// Cloudflare Pages "advanced mode" worker (works with dashboard drag-and-drop).
// Handles /api/reading (3-day memory per visitor IP, stored in KV binding READINGS)
// and passes every other request through to your static files.

const THREE_DAYS_SECONDS = 3 * 24 * 60 * 60;
const THREE_DAYS_MS = THREE_DAYS_SECONDS * 1000;

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' }
  });
}

function clientIp(request) {
  return request.headers.get('CF-Connecting-IP') || 'unknown';
}

async function getReading(request, env) {
  const stored = await env.READINGS.get(`reading:${clientIp(request)}`, { type: 'json' });
  if (!stored || stored.expiresAt <= Date.now()) return json({ reading: null });
  return json({ reading: stored });
}

async function saveReading(request, env) {
  let body;
  try { body = await request.json(); }
  catch (e) { return json({ error: 'Body must be JSON.' }, 400); }

  if (!Array.isArray(body.cards) || body.cards.length !== 3) {
    return json({ error: 'Expected { cards: [past, present, future] }.' }, 400);
  }

  const ip = clientIp(request);
  const existing = await env.READINGS.get(`reading:${ip}`, { type: 'json' });
  if (existing && existing.expiresAt > Date.now()) {
    return json({ reading: existing }); // keep the first reading for the full 3 days
  }

  const record = {
    cards: body.cards.map(String),
    createdAt: Date.now(),
    expiresAt: Date.now() + THREE_DAYS_MS
  };
  await env.READINGS.put(`reading:${ip}`, JSON.stringify(record), {
    expirationTtl: THREE_DAYS_SECONDS
  });
  return json({ reading: record });
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    if (url.pathname === '/api/reading') {
      if (!env.READINGS) {
        return json({ error: 'KV namespace READINGS is not bound to this project yet.' }, 500);
      }
      if (request.method === 'GET') return getReading(request, env);
      if (request.method === 'POST') return saveReading(request, env);
      return json({ error: 'Method not allowed.' }, 405);
    }

    return env.ASSETS.fetch(request);
  }
};
